package com.nutritrack.model;

public enum DietType {
    VEGAN,
    VEGETARIAN,
    OMNIVORE
}
